#!/bin/bash
qemu-aarch64-static -g 1234 prob