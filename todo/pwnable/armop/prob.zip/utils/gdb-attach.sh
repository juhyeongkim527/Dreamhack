#!/bin/bash
gdb-multiarch \
    -ex "target remote :1234" \