#!/bin/bash
qemu-aarch64-static prob