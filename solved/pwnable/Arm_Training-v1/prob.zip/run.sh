qemu-arm-static /arm
